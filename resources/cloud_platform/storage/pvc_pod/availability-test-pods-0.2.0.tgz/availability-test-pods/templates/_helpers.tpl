{{/*
Expand the name of the chart.
*/}}
{{- define "availability-test-pods.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
Truncated at 63 chars because some Kubernetes name fields are limited to this.
*/}}
{{- define "availability-test-pods.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "availability-test-pods.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels (immutable subset used in matchLabels)
*/}}
{{- define "availability-test-pods.selectorLabels" -}}
app.kubernetes.io/name: {{ include "availability-test-pods.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "availability-test-pods.labels" -}}
{{- $valid := list "application" "platform" }}
{{- if not (has (.Values.coreAlignment | default "application") $valid) }}
{{- fail "coreAlignment must be either 'application' or 'platform'" }}
{{- end }}
helm.sh/chart: {{ include "availability-test-pods.chart" . }}
{{ include "availability-test-pods.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.starlingx.io/component: {{ .Values.coreAlignment | default "application" }}
{{- end }}

{{/*
ServiceAccount name
*/}}
{{- define "availability-test-pods.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- .Values.serviceAccount.name | default (include "availability-test-pods.fullname" .) }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Log timestamp format - used in pod shell scripts
Requires GNU coreutils date for %3N (millisecond) support.
*/}}
{{- define "availability-test-pods.logFormat" -}}
date -u +%Y-%m-%dT%H:%M:%S.%3N
{{- end }}
